﻿Partial Class bDataSet
End Class


